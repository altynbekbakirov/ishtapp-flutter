package ulut.kg.ishapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
