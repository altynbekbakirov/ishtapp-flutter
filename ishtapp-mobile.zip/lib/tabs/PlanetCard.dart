class PlanetCard {
  String cardTitle;
  String cardImage;
  double topMargin;

  PlanetCard(String title, String imagePath, double marginTop) {
    cardTitle = title;
    cardImage = imagePath;
    topMargin = marginTop;
  }
}