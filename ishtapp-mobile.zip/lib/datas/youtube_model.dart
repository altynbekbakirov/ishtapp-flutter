class YoutubeModel {
  int id;
  String youtubeId;

  YoutubeModel({this.id, this.youtubeId});
}